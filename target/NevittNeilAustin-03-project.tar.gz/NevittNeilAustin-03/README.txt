mvn clean compile exec:java -Dexec.mainClass=app.Assignment03
