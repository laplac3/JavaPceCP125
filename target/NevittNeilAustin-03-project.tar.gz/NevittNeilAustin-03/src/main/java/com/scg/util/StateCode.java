package com.scg.util;

public enum StateCode {
	WA,
	CA,
	NY;
	
}
